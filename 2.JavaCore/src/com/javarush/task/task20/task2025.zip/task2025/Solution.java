package com.javarush.task.task20.task2025;

/* 
Алгоритмы-числа
*/

import com.sun.org.apache.xpath.internal.SourceTree;

import java.util.*;

import static java.lang.Math.pow;

public class Solution {
    static long[][] pows = new long[10][20];
    static {
        for (int i = 0; i < 10; i++) {
//            System.out.print(i + ":");
            for (int j = 0; j < 20; j++) {
                if(i==0){
                    pows[i][j] = 0;
                }else if(i==1){
                    pows[i][j] = 1;
                }else {
                    pows[i][j] = (long) pow(i, j);
                }
//                String format = "|%2d %2d %" + (j+2) + "d |";
//                System.out.printf(format, i,j, pows[i][j]);
            }
//            System.out.println("");
        }
    }

/*
    public static long[] getNumbers(long N) {
        List<Long> list = new ArrayList<>();
        long[] result = new long[30];
        int length = getLen(N);
//        System.out.printf("\nLength %d = %d\n", N, length);
//        isArmDigit(N);
        for (long i = 0; i <= N ; i++) {
//            System.out.printf("\nprocessing i = %d", i);
            if( isArmDigit(i) ) {
                list.add(i);
                System.out.printf(" %d", i);
            }
            if(list.size() > 30 ) break;
        }
        result = new long[list.size()];
        for (int i = 0; i < list.size(); i++) {
            result[i] = list.get(i);
        }
        Arrays.sort(result);
        return result;
    }
*/

    public static long[] getNumbers(long N) {
        final boolean[] done = {false, false, false};
        List<Long> list = new ArrayList<>();
        long[] result;
        long n = N;// > 912985153 ? 912985154 : N;


        Thread t0 = new Thread(new Runnable() {
            @Override
            public void run() {
//        System.out.printf("\nLength %d = %d\n", N, length);
//        isArmDigit(N);
                for (long i = 0; i <= n*14/20 ; i++) {
//            System.out.printf("\nprocessing i = %d", i);
                    if( isArmDigit(i) ) {
                        list.add(i);
                        System.out.printf(" t0 %d", i);
                    }
                    if(list.size() > 30 ) break;
                }
                System.out.println("\n t0 ends");
                done[0] = true;
            }
        });
        Thread t1 = new Thread(new Runnable() {
            @Override
            public void run() {
//        System.out.printf("\nLength %d = %d\n", N, length);
//        isArmDigit(N);
                for (long i = n*14/20; i <= n*17/20 ; i++) {
//            System.out.printf("\nprocessing i = %d", i);
                    if( isArmDigit(i) ) {
                        list.add(i);
                        System.out.printf(" t1 %d", i);
                    }
                    if(list.size() > 30 ) break;
                }
                System.out.println("\n t1 ends");
                done[1] = true;
            }
        });
        Thread t2 = new Thread(new Runnable() {
            @Override
            public void run() {
//        System.out.printf("\nLength %d = %d\n", N, length);
//        isArmDigit(N);
                for (long i = n*17/20; i <= n ; i++) {
//            System.out.printf("\nprocessing i = %d", i);
                    if( isArmDigit(i) ) {
                        list.add(i);
                        System.out.printf(" t2 %d", i);
                    }
                    if(list.size() > 30 ) break;
                }
                System.out.println("\n t2 ends");
                done[2] = true;
            }
        });
        t2.start();
        t1.start();
        t0.start();
        try {
            while( !done[0] || !done[1] || !done[2]) Thread.sleep(10);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        result = new long[list.size()];
        for (int i = 0; i < list.size(); i++) {
            result[i] = list.get(i);
        }
        Arrays.sort(result);
        return result;
    }


    public static boolean isArmDigit(long digit){
        char[] digits = String.valueOf(digit).toCharArray();
        long result = 0;
        int length = getLen(digit);
        for (int i = 0; i < digits.length; i++) {
            int inti = digits[i]-48;
//            System.out.println(inti);
            result += pows[inti][length];
        }

        return result==digit ? true : false;
    }

    public static int getLen(long digit){
        int numDigits = 1;
        if( digit > 999_999_999) { numDigits = 10;
            if (digit > 999_999_999_999_999_999L ) numDigits = 19;
            else if (digit >  99_999_999_999_999_999L ) numDigits = 18;
            else if (digit >   9_999_999_999_999_999L ) numDigits = 17;
            else if (digit >     999_999_999_999_999L ) numDigits = 16;
            else if (digit >      99_999_999_999_999L ) numDigits = 15;
            else if (digit >       9_999_999_999_999L ) numDigits = 14;
            else if (digit >         999_999_999_999L ) numDigits = 13;
            else if (digit >          99_999_999_999L ) numDigits = 12;
            else if (digit >           9_999_999_999L ) numDigits = 11;
        } else {
            if (digit > 99_999_999 ) numDigits = 9;
            else if (digit >  9_999_999 ) numDigits = 8;
            else if (digit >    999_999 ) numDigits = 7;
            else if (digit >     99_999 ) numDigits = 6;
            else if (digit >      9_999 ) numDigits = 5;
            else if (digit >        999 ) numDigits = 4;
            else if (digit >         99 ) numDigits = 3;
            else if (digit >          9 ) numDigits = 2;
        }
        return numDigits;
    }


    public static void main(String[] args) {
        long sTime = System.currentTimeMillis();
        System.out.println();
        for ( long l : getNumbers(Integer.MAX_VALUE)) System.out.printf(" %d", l );

        System.out.printf("\nElapsed time: %d", System.currentTimeMillis()-sTime );
    }
}
